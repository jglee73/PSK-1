#pragma once


// ...
#define ALID__PLC_OFFLINE							1

#define ALID__PLC_AI_ERROR							2
#define ALID__PLC_DI_ERROR							3
#define ALID__PLC_SI_ERROR							4


// ...
#define  STR__CLEAR									"CLEAR"

