#pragma once


extern int Macro__StringArrray_From_String(const CString& str_org_data,const CString& str_sep,CStringArray& l_data);
extern int Macro__Hexa_From_String(const CString& str_data);

